#!/bin/bash
java -Dch.ethz.jadabs.jxme.peeralias=$HOSTNAME -jar ~/.maven/repository/osgi/jars/framework-1.3.0.jar
