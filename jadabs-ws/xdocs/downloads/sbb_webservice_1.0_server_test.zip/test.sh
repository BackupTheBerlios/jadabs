#!/bin/sh

javac -classpath src;lib/ksoap-1.2-j2se.zip -d . src/ch/ethz/jadabs/webservices/sbb/test/Test.java

java -classpath .;lib/ksoap-1.2-j2se.zip ch.ethz.jadabs.webservices.sbb.test.Test