/*
 * Created on 02.11.2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ch.ethz.jadabs.amonem.ui.perspective;

import org.eclipse.core.runtime.Plugin;

import ch.ethz.jadabs.amonem.ui.views.GraphView;
import ch.ethz.jadabs.amonem.ui.views.PeerListView;
import ch.ethz.jadabs.amonem.ui.views.PropertyView;


/**
 * @author Markus
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Manager {

	GraphView gv;
	PeerListView plv;
	PropertyView pv;
	
	public Manager(){
		
	}
	
}
