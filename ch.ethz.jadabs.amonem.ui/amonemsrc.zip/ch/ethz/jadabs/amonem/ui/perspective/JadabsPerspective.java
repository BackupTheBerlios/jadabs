/*
 * Created on 30.11.2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ch.ethz.jadabs.amonem.ui.perspective;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;



public class JadabsPerspective implements IPerspectiveFactory
{

		/* (non-Javadoc)
		 * @see org.eclipse.ui.IPerspectiveFactory#createInitialLayout(org.eclipse.ui.IPageLayout)
		 */
		public void createInitialLayout(IPageLayout layout) {

			 defineLayout(layout);
			
		}
		
		
		public void defineLayout(IPageLayout layout) {
			
	        // Editors are placed for free.
	        String editorArea = layout.getEditorArea();
	        layout.setEditorAreaVisible(false); 

	        // Place navigator and outline to left of
	        // editor area.
	        IFolderLayout lists = layout.createFolder("List", IPageLayout.LEFT, (float) 0.26, editorArea);
	        lists.addView("PeersViewId");
	        lists.addView("GroupsViewId");
	        
	        IFolderLayout property = layout.createFolder("Properties", IPageLayout.BOTTOM, (float) 0.80, editorArea);
	        property.addView("PropertyViewId");
	        
	        IFolderLayout main = layout.createFolder("Main", IPageLayout.TOP, (float) 0.00, editorArea);
	        main.addView("JadabsViewId");
	        main.addView("GraphViewId");
	        
	        
	        
		}
		
}
